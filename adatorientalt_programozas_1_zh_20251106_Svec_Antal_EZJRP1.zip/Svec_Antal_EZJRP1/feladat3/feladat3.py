#!/usr/bin/env python3
# coding: utf-8

PROMPT = "A sor indexe (kilépés: 0): "

def get_pascal_triangle_row(id):
    triangle = [[1]]
    for i in range(id-1):
        new_row = [1]
        for j in range(1, len(triangle[i])):
            new_row.append(triangle[i][j] + triangle[i][j-1])
        new_row.append(1)
        triangle.append(new_row)

    return " ".join([str(n) for n in triangle[-1]])



def main():

    index = int(input(PROMPT))

    while index != 0:
        print(get_pascal_triangle_row(index))
        index = int(input(PROMPT))
    print("bye")
        




if __name__ == "__main__":
    main()
