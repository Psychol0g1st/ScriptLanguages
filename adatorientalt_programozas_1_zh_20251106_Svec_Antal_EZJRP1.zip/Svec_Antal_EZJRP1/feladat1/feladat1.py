#!/usr/bin/env python3
# coding: utf-8


def read_file_lines(file_name):
    lines = []
    with open(file_name, "r") as f:
        lines = f.readlines()
    return lines


def make_move(visited, current_pos, direction):
    if direction == "^":
        current_pos[0] += 1

    elif direction == ">":
        current_pos[1] += 1

    elif direction == "v":
        current_pos[0] -= 1

    else:  # direction == "<"
        current_pos[1] -= 1

    pos_str = f"{current_pos[0]},{current_pos[1]}"
    if pos_str in visited:
        visited[pos_str] += 1
    else:
        visited[pos_str] = 1


def main():
    path = "".join(read_file_lines("input.txt")).strip()
    visited = { "0,0" : 1 }
    current_pos = [0,0]
    for direction in path:
        make_move(visited, current_pos, direction)
    print(len(visited))

        




if __name__ == "__main__":
    main()