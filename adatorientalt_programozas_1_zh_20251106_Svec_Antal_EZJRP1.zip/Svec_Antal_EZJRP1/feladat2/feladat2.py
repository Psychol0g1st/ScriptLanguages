#!/usr/bin/env python3
# coding: utf-8

def is_pitegorasz_szamharmas(a,b,c):
    return a**2 + b**2 == c**2



def main():
    a = 1
    b = 1
    c = 1
    is_found = False


    for i in range(1, 1000):
        if is_found:
            break
        for j in range(i, 1000):
            if is_found:
                break
            for k in range(j, 1000):
                if is_found:
                    break
                if is_pitegorasz_szamharmas(i,j,k) and i+j+k == 1000:
                    a=i
                    b=j
                    c=k
                    is_found = True

    print(f"{a} * {b} * {c} = {a*b*c}")

        




if __name__ == "__main__":
    main()
