#!/usr/bin/env python3
# coding: utf-8

import sys

def read_file_lines(file_name):
    lines = []
    with open(file_name, "r") as f:
        lines = f.readlines()
    return lines

def convert_data(lines):
    data = []
    for line in lines:
        values = line.strip().split(";")
        record = {}
        record["name"] = values[5]
        record["ssn"] = values[8]
        data.append(record)
    return data


def main():
    if(len(sys.argv) != 2):
        print("Hibás paraméterezés! Csak egy számjegyet kell megadni!", file=sys.stderr)
        return
    digit = sys.argv[1]

    data = convert_data(read_file_lines("data.csv"))
    filtered_str = "\n".join([f"{record["name"]};{record["ssn"]}" for record in data if record["ssn"][0] == digit])
    print(filtered_str)
    

        




if __name__ == "__main__":
    main()
